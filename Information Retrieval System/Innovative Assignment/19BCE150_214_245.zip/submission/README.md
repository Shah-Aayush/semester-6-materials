# Query by Humming



- Outline
	- Introduction
	- keywords
	- Music Information Retrieval techniques
		- query by text, example, humming [brief intro]
			- 2.3 [main]
			- 2.1, 2.2 [sub]
		- related work
			- 3.5 [main]
			- 3.1-3.6 [sub]
	- Proposed system
		- whole section
	- Experiments and results
		- whole section
	- conclusion
	- future work
	- references